document.addEventListener('DOMContentLoaded', () => {
    const submitButton = document.querySelector('.select-button');
    const checkboxes = document.querySelectorAll('.ingredient-list input[type="checkbox"]');

    // Function to fetch and display recipes
    const fetchAndDisplayRecipes = () => {
        fetch('/getRecipes')
            .then(response => response.json())
            .then(recipes => {
                const recipeContainer = document.getElementById('recipeContainer');
                // Clear previous recipes
                recipeContainer.innerHTML = '';

                // Display all recipes
                recipes.forEach(recipe => {
                    const recipeCard = document.createElement('div');
                    recipeCard.className = 'recipe-card';

                    const recipeImage = document.createElement('img');
                    recipeImage.src = recipe.image ? '/uploads/${recipe.image}' : 'assets/default_recipe_image.png';
                    recipeImage.alt = recipe.name;
                    recipeCard.appendChild(recipeImage);

                    const recipeName = document.createElement('h3');
                    recipeName.textContent = recipe.name;
                    recipeCard.appendChild(recipeName);

                    recipeCard.addEventListener('click', () => {
                        window.location.href = `recipeDetail.html?id=${recipe.id}`;
                    });

                    recipeContainer.appendChild(recipeCard);
                });
            })
            .catch(error => {
                console.error('Error fetching recipes:', error);
            });
    };

    // Fetch and display recipes when page loads
    fetchAndDisplayRecipes();

    // Event listener for Submit button click
    submitButton.addEventListener('click', () => {
        // Get selected ingredients
        const selectedIngredients = [];
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                selectedIngredients.push(checkbox.nextElementSibling.textContent.trim());
            }
        });

        // Check if at least 1 ingredient is selected
        if (selectedIngredients.length < 1) {
            alert('Please select at least 1 ingredient.');
            return;
        }

        // Clear previous recipes
        recipeContainer.innerHTML = '';

        // Fetch and display filtered recipes based on selected ingredients
        fetch('/getRecipes')
            .then(response => response.json())
            .then(recipes => {
                const recipeContainer = document.getElementById('recipeContainer');
                const filteredRecipes = recipes.filter(recipe =>
                    selectedIngredients.every(ingredient => recipe.ingredients.includes(ingredient))
                );

                // Display filtered recipes
                if (filteredRecipes.length > 0) {
                    filteredRecipes.forEach(recipe => {
                        const recipeCard = document.createElement('div');
                        recipeCard.className = 'recipe-card';

                        const recipeImage = document.createElement('img');
                        recipeImage.src = recipe.image ? '/uploads/${recipe.image}' : 'assets/default_recipe_image.png';
                        recipeImage.alt = recipe.name;
                        recipeCard.appendChild(recipeImage);

                        const recipeName = document.createElement('h3');
                        recipeName.textContent = recipe.name;
                        recipeCard.appendChild(recipeName);

                        recipeCard.addEventListener('click', () => {
                            window.location.href = `recipeDetail.html?id=${recipe.id}`;
                        });

                        recipeContainer.appendChild(recipeCard);
                    });
                } else {
                    const noRecipeMessage = document.createElement('p');
                    noRecipeMessage.textContent = 'No recipes found for the selected ingredients.';
                    recipeContainer.appendChild(noRecipeMessage);
                }
            })
            .catch(error => {
                console.error('Error fetching recipes:', error);
            });
    });
});
