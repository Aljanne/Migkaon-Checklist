document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const recipeId = urlParams.get('id');

    if (recipeId) {
        fetch(`/getRecipeDetails/${recipeId}`)
            .then(response => response.json())
            .then(recipe => {
                const recipeDetailContainer = document.getElementById('recipeDetailContainer');

                const recipeImage = document.createElement('img');
                recipeImage.src = recipe.image ? recipe.image : 'assets/default_recipe_image.png';
                recipeImage.alt = recipe.name;

                const recipeNameElement = document.createElement('h1');
                recipeNameElement.textContent = recipe.name;

                const recipeIngredients = document.createElement('div');
                recipeIngredients.innerHTML = `<h2>Ingredients</h2><p>${recipe.ingredients}</p>`;

                const recipeInstructions = document.createElement('div');
                recipeInstructions.innerHTML = `<h2>Instructions</h2><p>${recipe.instructions}</p>`;

                recipeDetailContainer.appendChild(recipeImage);
                recipeDetailContainer.appendChild(recipeNameElement);
                recipeDetailContainer.appendChild(recipeIngredients);
                recipeDetailContainer.appendChild(recipeInstructions);
            })
            .catch(error => {
                console.error('Error fetching recipe details:', error);
            });
    } else {
        console.error('No recipe ID provided in the URL.');
    }
});